<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Page not found &#8211; James October</title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="http://october02.themes.tvda.eu/demo02/xmlrpc.php">

                <script type="text/javascript">document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script>
                        <script type="text/javascript">
                var yith_wcwl_plugin_ajax_web_url = 'http://october02.themes.tvda.eu/demo02/wp-admin/admin-ajax.php';
                var login_redirect_url = 'http://october02.themes.tvda.eu/demo02/wp-login.php?redirect_to=%2Fdemo02%2Fblog%2Fmediaelement-and-player.js';
            </script>
        <link rel="alternate" type="application/rss+xml" title="James October &raquo; Feed" href="http://october02.themes.tvda.eu/demo02/feed/" />
<link rel="alternate" type="application/rss+xml" title="James October &raquo; Comments Feed" href="http://october02.themes.tvda.eu/demo02/comments/feed/" />
	
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/october02.themes.tvda.eu\/demo02\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.2.2"}};
			!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='mmpm_mega_main_menu-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/plugins/mega_main_menu/src/css/cache.skin.css?ver=4.2.2' type='text/css' media='all' />
<link rel='stylesheet' id='sb_instagram_styles-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/plugins/instagram-feed/css/sb-instagram.css?ver=1.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='sb_instagram_icons-css'  href='//netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css?1&#038;ver=4.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/plugins/revslider/rs-plugin/css/settings.css?ver=4.6.92' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}
</style>
<link rel='stylesheet' id='magnific-popup-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/plugins/elite-addons-vc/assets/libs/magnific-popup/magnific-popup.min.css?ver=0.9.9' type='text/css' media='all' />
<link rel='stylesheet' id='iv-oswald-webfont-css'  href='http://fonts.googleapis.com/css?family=Oswald%3A400%2C700&#038;ver=1' type='text/css' media='all' />
<link rel='stylesheet' id='iv-roboto-cond-webfont-css'  href='http://fonts.googleapis.com/css?family=Roboto+Condensed%3A400%2C700&#038;ver=1' type='text/css' media='all' />
<link rel='stylesheet' id='ivan-font-awesome-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/css/libs/font-awesome-css/font-awesome.min.css?ver=4.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='ivan-elegant-icons-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/css/libs/elegant-icons/elegant-icons.min.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='ivan-theme-styles-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/css/theme-styles.min.css?ver=1' type='text/css' media='all' />
<link rel='stylesheet' id='ivan-default-style-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/style.css?ver=4.2.2' type='text/css' media='all' />
<!--[if IE]>
<link rel='stylesheet' id='ie-ivan-theme-styles-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/css/ie.css' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='woocommerce-layout-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/css/woocommerce/css/woocommerce-layout.css?ver=2.3.10' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/css/woocommerce/css/woocommerce-smallscreen.css?ver=2.3.10' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/css/woocommerce/css/woocommerce.css?ver=2.3.10' type='text/css' media='all' />
<link rel='stylesheet' id='ivan_owl_carousel-css'  href='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/css/libs/owl-carousel/owl.carousel.min.css?ver=4.2.2' type='text/css' media='all' />
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-includes/js/jquery/jquery.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/plugins/login-with-ajax/login-with-ajax.js?ver=4.2.2'></script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.tools.min.js?ver=4.6.92'></script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.revolution.min.js?ver=4.6.92'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/demo02\/wp-admin\/admin-ajax.php","i18n_view_cart":"View Cart","cart_url":"","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='//october02.themes.tvda.eu/demo02/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=2.3.10'></script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=4.5.2'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://october02.themes.tvda.eu/demo02/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://october02.themes.tvda.eu/demo02/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.2.2" />
<meta name="generator" content="WooCommerce 2.3.10" />
		<script type="text/javascript">
			jQuery(document).ready(function() {
				// CUSTOM AJAX CONTENT LOADING FUNCTION
				var ajaxRevslider = function(obj) {
				
					// obj.type : Post Type
					// obj.id : ID of Content to Load
					// obj.aspectratio : The Aspect Ratio of the Container / Media
					// obj.selector : The Container Selector where the Content of Ajax will be injected. It is done via the Essential Grid on Return of Content
					
					var content = "";

					data = {};
					
					data.action = 'revslider_ajax_call_front';
					data.client_action = 'get_slider_html';
					data.token = '8787dd6dec';
					data.type = obj.type;
					data.id = obj.id;
					data.aspectratio = obj.aspectratio;
					
					// SYNC AJAX REQUEST
					jQuery.ajax({
						type:"post",
						url:"http://october02.themes.tvda.eu/demo02/wp-admin/admin-ajax.php",
						dataType: 'json',
						data:data,
						async:false,
						success: function(ret, textStatus, XMLHttpRequest) {
							if(ret.success == true)
								content = ret.data;								
						},
						error: function(e) {
							console.log(e);
						}
					});
					
					 // FIRST RETURN THE CONTENT WHEN IT IS LOADED !!
					 return content;						 
				};
				
				// CUSTOM AJAX FUNCTION TO REMOVE THE SLIDER
				var ajaxRemoveRevslider = function(obj) {
					return jQuery(obj.selector+" .rev_slider").revkill();
				};

				// EXTEND THE AJAX CONTENT LOADING TYPES WITH TYPE AND FUNCTION
				var extendessential = setInterval(function() {
					if (jQuery.fn.tpessential != undefined) {
						clearInterval(extendessential);
						if(typeof(jQuery.fn.tpessential.defaults) !== 'undefined') {
							jQuery.fn.tpessential.defaults.ajaxTypes.push({type:"revslider",func:ajaxRevslider,killfunc:ajaxRemoveRevslider,openAnimationSpeed:0.3});   
							// type:  Name of the Post to load via Ajax into the Essential Grid Ajax Container
							// func: the Function Name which is Called once the Item with the Post Type has been clicked
							// killfunc: function to kill in case the Ajax Window going to be removed (before Remove function !
							// openAnimationSpeed: how quick the Ajax Content window should be animated (default is 0.3)
						}
					}
				},30);
			});
		</script>
			<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="http://october02.themes.tvda.eu/demo02/wp-content/plugins/js_composer/assets/css/vc-ie8.css" media="screen"><![endif]-->
<!--[if gte IE 9]>
	<style type="text/css">
		..mega_main_menu,
		..mega_main_menu *
		{
			filter: none;
		}
	</style>
<![endif]-->

<!-- BEGIN Typekit Fonts for WordPress -->
<script type="text/javascript" src="//use.typekit.net/dlx6jsy.js"></script>
<script type="text/javascript">try{Typekit.load();}catch(e){}</script>
<!-- END Typekit Fonts for WordPress -->

<style type="text/css" title="dynamic-css" class="options-output">.logo{margin-top:30px;}#page-loader{background-color:#222222;}.index.content-wrapper.page-boxed-style, .index.content-wrapper.page-boxed-style.boxed-style, .archives.content-wrapper.page-boxed-style, .search.content-wrapper.page-boxed-style{background-color:#333333;}.single-post.content-wrapper.page-boxed-style, .single-post.content-wrapper.page-boxed-style.boxed-style{background-color:#333333;}.iv-layout.header{color:#ffffff;}.iv-layout.header{color:#bcbcbc;}.ivan-main-layout-aside.aside-header-wrapper.ivan-main-layout-aside-right, .ivan-main-layout-aside.aside-header-wrapper.ivan-main-layout-aside-left{background-color:#222222;}.simple-left-right .logo{padding-top:80px;}</style><style type="text/css"></style><style type="text/css"></style><style type="text/css"></style>                                    <style type="text/css">
                    .simple-left-right .mega_main_menu .mega_main_menu_ul > li > .item_link {border-bottom: 1px solid rgba(255, 255, 255, 0.1);}
.simple-left-right .modules-row {border-bottom: 1px solid rgba(255, 255, 255, 0.1);border-top: 1px solid rgba(255, 255, 255, 0.1);}
.simple-left-right .single-module-row {padding: 35px 25px;}
.blog-masonry.style-simple {background: #333;}
.title-wrapper-divider {display:none;}                </style>
	<style type="text/css">
	.ivan-staff-wrapper .social-icons a:hover,
	.ivan-call-action.primary-bg.with-icon .call-action-icon i,
	.ivan-button.outline:hover,
	.ivan-pricing-table.default.dark-bg .signup:hover,
	.ivan-pricing-table.default.black-bg .signup:hover,
	.ivan-pricing-table.big-price .top-section .adquire-plan .signup:hover,
	.ivan-pricing-table.description-support .bottom-section .signup:hover,
	.ivan-pricing-table.subtitle .bottom-section .signup:hover,
	.ivan-pricing-table.subtitle.dark-bg .signup:hover,
	.ivan-pricing-table.subtitle.black-bg .signup:hover,
	.ivan-pricing-table.small-desc .bottom-section .signup:hover,
	.ivan-pricing-table.small-desc.dark-bg .signup:hover,
	.ivan-pricing-table.small-desc.black-bg .signup:hover,
	.ivan-vc-filters a.current,.ivan-vc-filters a:hover,
	.marker-icon.ivan-gmap-marker,
	.ivan-title-wrapper.primary-bg .icon-above i,.ivan-title-wrapper.primary-bg a,.ivan-title-wrapper.primary-bg a:hover,.ivan-title-wrapper.primary-bg strong,
	.ivan-service .main-icon,
	.ivan-service.primary-bg .fa-stack .main-icon,
	.ivan-icon-box.primary-bg .icon-box-holder .main-icon,
	.ivan-icon-wrapper .primary-bg .ivan-icon,
	.ivan-icon-wrapper .primary-bg .ivan-font-stack .stack-holder,.ivan-icon-wrapper .primary-bg a:hover,
	.ivan-icon-wrapper .primary-bg .ivan-font-stack.with-link:hover .stack-holder,
	.ivan-icon-list.primary-bg i,
	.ivan-list.primary-bg.number ul>li:before,
	a,
	a:hover,
	.btn-primary .badge,
	.btn-link,
	.iv-layout.top-header a:hover,
	.iv-layout.top-header .woo-cart:hover .basket,.iv-layout.top-header.light .woo-cart:hover .basket,.iv-layout.top-header .woo-cart:hover .cart-total .amount,.iv-layout.top-header .woo-cart:hover .top,.iv-layout.top-header.light .woo-cart:hover .top,
	.top-header .mega_main_menu .mega_main_menu_ul>li.current-menu-ancestor>.item_link,.top-header .mega_main_menu .mega_main_menu_ul>li.current-menu-item>.item_link,.top-header .mega_main_menu .mega_main_menu_ul>li.highlight_style>.item_link,.top-header .mega_main_menu .mega_main_menu_ul>li.highlight_style>.item_link:hover,
	.top-header .mega_main_menu.direction-horizontal .mega_main_menu_ul>li.button_style>.item_link:hover>.item_link_content,
	.iv-layout.header a:hover,
	.iv-layout.header .woo-cart:hover .basket,.iv-layout.header .woo-cart:hover .cart-total .amount,.iv-layout.header .woo-cart:hover .top,
	.header .mega_main_menu .mega_main_menu_ul>li.highlight_style>.item_link,.header .mega_main_menu .mega_main_menu_ul>li.highlight_style>.item_link:hover,
	.header .mega_main_menu.direction-horizontal .mega_main_menu_ul>li.button_style>.item_link:hover>.item_link_content,
	.iv-layout.footer .constrast-text a,
	a.jm-post-like:active,a.jm-post-like:focus,a.jm-post-like:hover,a.liked:active,a.liked:focus,a.liked:hover,
	.post .entry-title a,
	.blog-large.style-simple .format-quote .quote-main,
	.blog-large.style-simple .format-quote .quote-main a,
	.blog-large.style-simple .format-status .status-main,
	.blog-large.style-simple .format-status .status-main a,
	.blog-large.style-bottom-meta .format-quote .quote-main,
	.blog-large.style-bottom-meta .format-quote .quote-main a,
	.blog-large.style-bottom-meta .format-status .status-main,
	.blog-large.style-bottom-meta .format-status .status-main a,
	.blog-large.style-aside-date .format-quote .quote-main,
	.blog-large.style-aside-date .format-quote .quote-main a,
	.blog-large.style-aside-date .format-status .status-main,
	.blog-large.style-aside-date .format-status .status-main a,
	.blog-medium.style-simple .format-quote .quote-main,
	.blog-medium.style-simple .format-quote .quote-main a,
	.blog-medium.style-simple .format-status .status-main,
	.blog-medium.style-simple .format-status .status-main a,
	.blog-masonry.style-simple .format-quote .quote-main,
	.blog-masonry.style-simple .format-quote .quote-main a,
	.blog-masonry.style-simple .format-status .status-main,
	.blog-masonry.style-simple .format-status .status-main a,
	.blog-full.style-polaroid .format-quote .quote-main,
	.blog-full.style-polaroid .format-quote .quote-main a,
	.blog-full.style-polaroid .format-status .status-main,
	.blog-full.style-polaroid .format-status .status-main a,
	.single-post .format-quote .quote-main,
	.single-post .format-quote .quote-main a,
	.single-post .format-status .status-main,
	.single-post .format-status .status-main a,
	.entry-author-meta .author-social-icon:hover,
	#comments .comment-body .comment-reply-link:hover,
	.woocommerce ul.products li.product .button:hover,
	.woocommerce-page ul.products li.product .button:hover,
	.woocommerce div.product div.summary span.price,
	.woocommerce-page div.product div.summary span.price,
	.woocommerce div.product div.summary p.price,
	.woocommerce-page div.product div.summary p.price,
	.woocommerce p.stars a:hover,
	.woocommerce-page p.stars a:hover,
	.ivan-product-popup .summary h3 a:hover,
	.woocommerce .widget_price_filter .price_slider_amount .button,
	.woocommerce-page .widget_price_filter .price_slider_amount .button,
	.woocommerce .widget_layered_nav ul li a:hover,
	.woocommerce-page .widget_layered_nav ul li a:hover,
	.woocommerce .widget_product_categories .product-categories li a a:hover,
	.woocommerce-page .widget_product_categories .product-categories li a a:hover {
	  color: #31ca8f;
	}

	.ivan-button:hover,
	.ivan-button.outline:hover hr,
	.ivan-button.no-border:hover,
	.ivan-button.primary-bg,
	.ivan-projects .ivan-project.hide-entry .entry,
	.ivan-projects .ivan-project.outer-square .entry,
	.ivan-projects .ivan-project.lateral-cover .entry,
	.ivan-projects .ivan-project.smooth-cover .entry,
	.ivan-testimonial.primary-bg.boxed-left .testimonial-content,
	.ivan-service .fa-stack,
	.ivan-service.primary-bg,
	.ivan-progress.primary-bg .ivan-progress-inner,
	.ivan-icon-box.primary-bg .icon-box-holder .fa-stack,
	.ivan-icon-boxed-holder.primary-bg .ivan-icon-boxed-icon-inner .fa-stack,
	.ivan-icon-wrapper .primary-bg .ivan-font-stack-square,
	.ivan-icon-list.primary-bg.circle i,
	.ivan-list.primary-bg.number.circle-in ul>li:before,
	.ivan-list.primary-bg.circle ul>li:before,
	.ivan-quote.primary-bg blockquote,
	.ivan-tabs-wrap .wpb_tour_tabs_wrapper.iv-tabs.iv-boxed .wpb_tabs_nav li.ui-tabs-active a,
	.ivan-vc-separator.primary-bg,
	.btn.active,.btn:active,.btn:focus,.btn:hover,.button.active,.button:active,.button:focus,.button:hover,.open .dropdown-toggle.btn,.open .dropdown-toggle.button,.open .dropdown-togglebutton,.open .dropdown-toggleinput[type=submit],button.active,button:active,button:focus,button:hover,input[type=submit].active,input[type=submit]:active,input[type=submit]:focus,input[type=submit]:hover,
	.btn-default.active,.btn-default:active,.btn-default:focus,.btn-default:hover,.open .dropdown-toggle.btn-default,
	.btn-primary,.btn-primary.active,.btn-primary:active,.btn-primary:focus,.btn-primary:hover,.open .dropdown-toggle.btn-primary,
	.btn-primary.disabled,.btn-primary.disabled.active,.btn-primary.disabled:active,.btn-primary.disabled:focus,.btn-primary.disabled:hover,.btn-primary[disabled],.btn-primary[disabled].active,.btn-primary[disabled]:active,.btn-primary[disabled]:focus,.btn-primary[disabled]:hover,fieldset[disabled] .btn-primary,fieldset[disabled] .btn-primary.active,fieldset[disabled] .btn-primary:active,fieldset[disabled] .btn-primary:focus,fieldset[disabled] .btn-primary:hover,
	.btn-warning.active,.btn-warning:active,.btn-warning:focus,.btn-warning:hover,.open .dropdown-toggle.btn-warning,
	.btn-danger.active,.btn-danger:active,.btn-danger:focus,.btn-danger:hover,.open .dropdown-toggle.btn-danger,
	.btn-success.active,.btn-success:active,.btn-success:focus,.btn-success:hover,.open .dropdown-toggle.btn-success,
	.btn-info.active,.btn-info:active,.btn-info:focus,.btn-info:hover,.open .dropdown-toggle.btn-info,
	.simple-left-right .widget-area .widget.widget_tag_cloud a:hover,
	.page-links a:hover span,
	.single-post .entry-tags a:hover,
	.content-wrapper .wpb_widgetised_column .widget.widget_tag_cloud a:hover,.sidebar .widget.widget_tag_cloud a:hover,
	.ivan-pricing-table.default.primary-bg,
	.ivan-pricing-table.subtitle .featured-table-text,
	.ivan-pricing-table.subtitle.primary-bg,
	.ivan-pricing-table.small-desc .featured-table-text,
	.ivan-pricing-table.small-desc.primary-bg,
	.ivan-projects .ivan-project.cover-entry .entry .read-more a:hover,
	.ivan-projects .ivan-project.soft-cover .entry .read-more a:hover,
	.ivan-icon-wrapper .primary-bg .ivan-font-stack-square.with-link:hover,
	.wpb_toggle.iv-toggle.boxed-arrow.wpb_toggle_title_active,
	.ivan_acc_holder.iv-accordion.with-arrow .ui-state-active,
	.iv-social-icon.circle:hover,.iv-social-icon.square:hover,
	.iv-mobile-menu-wrapper .current-menu-item>a,
	.iv-layout.top-header input[type=submit]:hover,
	.iv-layout.top-header .social-icons a:hover,
	.iv-layout.top-header .woo-cart .buttons a:hover,
	.iv-layout.top-header .login-ajax .lwa input[type=submit]:hover,
	.iv-layout.header input[type=submit]:hover,
	.iv-layout.header .woo-cart .buttons a:hover,
	.iv-layout.header .login-ajax .lwa input[type=submit]:hover,
	.mega_main_menu .default_dropdown .mega_dropdown > li > .item_link:hover,
	.mega_main_menu .multicolumn_dropdown .mega_dropdown li > a.item_link:hover,
	.simple-left-right .widget-area .widget input[type=submit]:hover,
	.dynamic-footer .wpb_widgetised_column .widget .iv-social-icon.circle:hover,.dynamic-footer .wpb_widgetised_column .widget .iv-social-icon.square:hover,.iv-layout.footer .widget .iv-social-icon.circle:hover,.iv-layout.footer .widget .iv-social-icon.square:hover,
	.iv-layout.bottom-footer .iv-social-icon.circle:hover,.iv-layout.bottom-footer .iv-social-icon.square:hover,
	#infinite-handle span:hover,
	.sticky-post-holder,
	.thumbnail-hover .overlay,
	#all-site-wrapper .mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-current,#all-site-wrapper .mejs-controls .mejs-time-rail .mejs-time-current,
	.post-nav-fixed .nl-infos,
	.iv-layout.title-wrapper.title-wrapper-large h2:after,
	.woocommerce ul.products li.product .quick-view:hover, .woocommerce-page ul.products li.product .quick-view:hover,
	.woocommerce .widget_price_filter .ui-slider .ui-slider-range,
	.woocommerce-page .widget_price_filter .ui-slider .ui-slider-range {
		background-color: #31ca8f;
	}

	.ivan-button.outline:hover {
		background-color: transparent;
	}

	.ivan-button:hover,
	.ivan-button.outline:hover,
	.ivan-button.no-border:hover,
	.ivan-button.primary-bg,
	.ivan-button.primary-bg.outline.text-separator.with-icon .text-btn,
	.ivan-pricing-table.default.dark-bg .signup:hover,
	.ivan-pricing-table.default.black-bg .signup:hover,
	.ivan-pricing-table.big-price .top-section .adquire-plan .signup:hover,
	.ivan-pricing-table.description-support .bottom-section .signup:hover,
	.ivan-pricing-table.subtitle .bottom-section .signup:hover,
	.ivan-pricing-table.subtitle.dark-bg .signup:hover,
	.ivan-pricing-table.subtitle.black-bg .signup:hover,
	.ivan-pricing-table.small-desc .bottom-section .signup:hover,
	.ivan-pricing-table.small-desc.dark-bg .signup:hover,
	.ivan-pricing-table.small-desc.black-bg .signup:hover,
	.ivan-projects .ivan-project.cover-entry .entry .read-more a:hover,
	.ivan-projects .ivan-project.soft-cover .entry .read-more a:hover,
	.btn.active,.btn:active,.btn:focus,.btn:hover,.button.active,.button:active,.button:focus,.button:hover,.open .dropdown-toggle.btn,.open .dropdown-toggle.button,.open .dropdown-togglebutton,.open .dropdown-toggleinput[type=submit],button.active,button:active,button:focus,button:hover,input[type=submit].active,input[type=submit]:active,input[type=submit]:focus,input[type=submit]:hover,
	.btn-default.active,.btn-default:active,.btn-default:focus,.btn-default:hover,.open .dropdown-toggle.btn-default,
	.btn-primary,.btn-primary.active,.btn-primary:active,.btn-primary:focus,.btn-primary:hover,.open .dropdown-toggle.btn-primary,
	.btn-primary.disabled,.btn-primary.disabled.active,.btn-primary.disabled:active,.btn-primary.disabled:focus,.btn-primary.disabled:hover,.btn-primary[disabled],.btn-primary[disabled].active,.btn-primary[disabled]:active,.btn-primary[disabled]:focus,.btn-primary[disabled]:hover,fieldset[disabled] .btn-primary,fieldset[disabled] .btn-primary.active,fieldset[disabled] .btn-primary:active,fieldset[disabled] .btn-primary:focus,fieldset[disabled] .btn-primary:hover,
	.btn-warning.active,.btn-warning:active,.btn-warning:focus,.btn-warning:hover,.open .dropdown-toggle.btn-warning,
	.btn-danger.active,.btn-danger:active,.btn-danger:focus,.btn-danger:hover,.open .dropdown-toggle.btn-danger,
	.btn-success.active,.btn-success:active,.btn-success:focus,.btn-success:hover,.open .dropdown-toggle.btn-success,
	.btn-info.active,.btn-info:active,.btn-info:focus,.btn-info:hover,.open .dropdown-toggle.btn-info,
	.iv-layout.top-header input[type=email]:focus,.iv-layout.top-header input[type=password]:focus,.iv-layout.top-header input[type=search]:focus,.iv-layout.top-header input[type=text]:focus,.iv-layout.top-header textarea:focus,
	.iv-layout.top-header input[type=submit]:hover,
	.iv-layout.top-header .woo-cart:hover .basket,.iv-layout.top-header.light .woo-cart:hover .basket,.iv-layout.top-header .woo-cart:hover .cart-total .amount,.iv-layout.top-header .woo-cart:hover .top,.iv-layout.top-header.light .woo-cart:hover .top,
	.iv-layout.top-header .woo-cart .buttons a:hover,
	.iv-layout.top-header .login-ajax .lwa input[type=submit]:hover,
	.top-header .mega_main_menu.direction-horizontal .mega_main_menu_ul>li.button_style>.item_link:hover>.item_link_content,
	.iv-layout.header .woo-cart:hover .basket,.iv-layout.header .woo-cart:hover .cart-total .amount,.iv-layout.header .woo-cart:hover .top,
	.header .mega_main_menu .mega_main_menu_ul>li>.item_link:hover .item_link_content,
	.header .mega_main_menu.direction-horizontal .mega_main_menu_ul>li.button_style>.item_link:hover>.item_link_content,
	.simple-left-right .widget-area .widget.widget_tag_cloud a:hover,
	#infinite-handle span:hover,
	.single-post .entry-tags a:hover,
	.content-wrapper .wpb_widgetised_column .widget.widget_tag_cloud a:hover,.sidebar .widget.widget_tag_cloud a:hover,
	.ivan-service .fa-stack,
	.ivan-icon-box.primary-bg .icon-box-holder .fa-stack,
	.ivan-icon-boxed-holder.primary-bg .ivan-icon-boxed-icon-inner .fa-stack,
	.ivan-tabs-wrap .wpb_tour_tabs_wrapper.iv-tabs.iv-boxed .wpb_tabs_nav li.ui-tabs-active a,
	.ivan-tabs-wrap .wpb_tour_tabs_wrapper.iv-tabs.iv-boxed .wpb_tab,
	.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
	.woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle {
		border-color: #31ca8f;
	}
	
	#page-loader .spinner, #page-loader .spinner:before, #page-loader .spinner:after {
		border-top-color: #31ca8f;
	}

	.ivan-testimonial.primary-bg.boxed-left .testimonial-content:after {
		border-top-color: #31ca8f;
	}

	/* **** */
	/* Accent Color */
	/* **** */

	.ivan-button:hover,
	.ivan-button.primary-bg,
	.ivan-button.primary-bg:hover,
	.ivan-button.primary-bg.with-icon.icon-cover .icon-simple,
	.ivan-pricing-table.default.primary-bg .plan-infos,.ivan-pricing-table.default.primary-bg h3,.ivan-pricing-table.default.primary-bg li,.ivan-pricing-table.default.primary-bg li a,.ivan-pricing-table.default.primary-bg li a:hover,
	.ivan-pricing-table.default.primary-bg .signup,.ivan-pricing-table.default.primary-bg .signup:hover,
	.ivan-pricing-table.default.primary-bg .featured-table-text,
	.ivan-pricing-table.subtitle .featured-table-text,
	.ivan-pricing-table.subtitle.primary-bg .plan-infos,.ivan-pricing-table.subtitle.primary-bg .plan-subtitle,.ivan-pricing-table.subtitle.primary-bg h3,.ivan-pricing-table.subtitle.primary-bg li,.ivan-pricing-table.subtitle.primary-bg li a,.ivan-pricing-table.subtitle.primary-bg li a:hover,
	.ivan-pricing-table.subtitle.primary-bg .signup,.ivan-pricing-table.subtitle.primary-bg .signup:hover,
	.ivan-pricing-table.subtitle.primary-bg .featured-table-text,
	.ivan-pricing-table.small-desc .featured-table-text,
	.ivan-pricing-table.small-desc.primary-bg .plan-infos,.ivan-pricing-table.small-desc.primary-bg .plan-subtitle,.ivan-pricing-table.small-desc.primary-bg h3,.ivan-pricing-table.small-desc.primary-bg li,.ivan-pricing-table.small-desc.primary-bg li a,.ivan-pricing-table.small-desc.primary-bg li a:hover,
	.ivan-pricing-table.small-desc.primary-bg .signup,.ivan-pricing-table.small-desc.primary-bg .signup:hover,
	.ivan-pricing-table.small-desc.primary-bg .featured-table-text,
	.ivan-projects .ivan-project.cover-entry .entry .read-more a:hover,
	.ivan-projects .ivan-project.soft-cover .entry .read-more a:hover,
	.ivan-testimonial.primary-bg.boxed-left .testimonial-content,
	.ivan-testimonial.primary-bg.boxed-left .testimonial-content a,.ivan-testimonial.primary-bg.boxed-left .testimonial-content a:hover,
	.ivan-service .fa-stack .main-icon,
	.ivan-service.primary-bg .main-icon,.ivan-service.primary-bg .service-title,
	.ivan-icon-box.primary-bg .icon-box-holder .fa-stack .main-icon,
	.ivan-icon-boxed-holder.primary-bg .ivan-icon-boxed-icon-inner .fa-stack .main-icon,
	.ivan-icon-wrapper .primary-bg a,
	.ivan-icon-wrapper .primary-bg .ivan-font-stack .main-icon,
	.ivan-icon-wrapper .primary-bg .ivan-font-stack-square i,
	.ivan-icon-list.primary-bg.circle i,
	.ivan-list.primary-bg.number.circle-in ul>li:before,
	.ivan-quote.primary-bg blockquote .author,.ivan-quote.primary-bg blockquote .pull-left,.ivan-quote.primary-bg blockquote h5,
	.ivan-tabs-wrap .wpb_tour_tabs_wrapper.iv-tabs.iv-boxed .wpb_tabs_nav li.ui-tabs-active a,
	.wpb_toggle.iv-toggle.boxed-arrow.wpb_toggle_title_active,
	.wpb_toggle.iv-toggle.boxed-arrow.wpb_toggle_title_active .toggle-mark .toggle-mark-icon,
	.ivan_acc_holder.iv-accordion.with-arrow .ui-state-active .accordion-mark .accordion-mark-icon,.ivan_acc_holder.iv-accordion.with-arrow .ui-state-active a,
	.btn.active,.btn:active,.btn:focus,.btn:hover,.button.active,.button:active,.button:focus,.button:hover,.open .dropdown-toggle.btn,.open .dropdown-toggle.button,.open .dropdown-togglebutton,.open .dropdown-toggleinput[type=submit],button.active,button:active,button:focus,button:hover,input[type=submit].active,input[type=submit]:active,input[type=submit]:focus,input[type=submit]:hover,
	.btn-default.active,.btn-default:active,.btn-default:focus,.btn-default:hover,.open .dropdown-toggle.btn-default,
	.btn-primary,.btn-primary.active,.btn-primary:active,.btn-primary:focus,.btn-primary:hover,.open .dropdown-toggle.btn-primary,
	.btn-warning.active,.btn-warning:active,.btn-warning:focus,.btn-warning:hover,.open .dropdown-toggle.btn-warning,
	.btn-danger.active,.btn-danger:active,.btn-danger:focus,.btn-danger:hover,.open .dropdown-toggle.btn-danger,
	.btn-success.active,.btn-success:active,.btn-success:focus,.btn-success:hover,.open .dropdown-toggle.btn-success,
	.btn-info.active,.btn-info:active,.btn-info:focus,.btn-info:hover,.open .dropdown-toggle.btn-info,
	.iv-social-icon.circle:hover,.iv-social-icon.square:hover,
	.iv-layout.top-header input[type=submit]:hover,
	.iv-layout.top-header .social-icons a:hover,
	.iv-layout.top-header .woo-cart .buttons a:hover,
	.iv-layout.top-header .login-ajax .lwa input[type=submit]:hover,
	.iv-layout.header input[type=submit]:hover,
	.iv-layout.header .woo-cart .buttons a:hover,
	.iv-layout.header .login-ajax .lwa input[type=submit]:hover,
	.simple-left-right .widget-area .widget.widget_tag_cloud a:hover,
	.dynamic-footer .wpb_widgetised_column .widget .iv-social-icon.circle:hover,.dynamic-footer .wpb_widgetised_column .widget .iv-social-icon.square:hover,.iv-layout.footer .widget .iv-social-icon.circle:hover,.iv-layout.footer .widget .iv-social-icon.square:hover,
	.iv-layout.bottom-footer .iv-social-icon.circle:hover,.iv-layout.bottom-footer .iv-social-icon.square:hover,
	#infinite-handle span:hover,
	.sticky-post-holder,
	.paging-navigation a,
	.page-links a:hover span,
	.single-post .entry-tags a:hover,
	.post-nav-fixed .nl-infos,
	.post-nav-fixed:hover .nl-arrow-icon,
	.content-wrapper .wpb_widgetised_column .widget.widget_tag_cloud a:hover,.sidebar .widget.widget_tag_cloud a:hover {
		color: #fff;
	}

	.ivan-button:hover hr,
	.ivan-button.primary-bg hr,
	.ivan-button.primary-bg:hover hr,
	.ivan-service.primary-bg .fa-stack,
	.thumbnail-hover .thumb-cross:after,
	.thumbnail-hover .thumb-cross:before {
		background-color: #fff;
	}

	.ivan-pricing-table.default.primary-bg .signup,.ivan-pricing-table.default.primary-bg .signup:hover,
	.ivan-pricing-table.subtitle.primary-bg .signup,.ivan-pricing-table.subtitle.primary-bg .signup:hover,
	.ivan-pricing-table.small-desc.primary-bg .signup,.ivan-pricing-table.small-desc.primary-bg .signup:hover,
	.ivan-service.primary-bg .fa-stack {
		border-color: #fff;
	}

	/* **** */
	/* Darken/Lighten */
	/* **** */

	.ivan-button.primary-bg:hover,
	.ivan-button.primary-bg.outline hr,
	.ivan-button.primary-bg.outline:hover hr,
	.ivan-button.primary-bg.outline.icon-cover.with-icon .icon-simple,
	.ivan-pricing-table.default.primary-bg .featured-table-text,
	.ivan-pricing-table.subtitle.primary-bg .featured-table-text,
	.ivan-pricing-table.small-desc.primary-bg .featured-table-text,
	.post-nav-fixed:hover .nl-arrow-icon {
	  background-color: #24bd82;
	}

	.ivan-button.primary-bg.outline,
	.ivan-button.primary-bg.outline:hover,
	.iv-layout.footer .constrast-text a:hover,
	.post .entry-title a:hover,
	.woocommerce .widget_price_filter .price_slider_amount .button,
	.woocommerce-page .widget_price_filter .price_slider_amount .button {
	  color: #24bd82;
	}

	.ivan-pricing-table.default.primary-bg .featured-table-text,
	.ivan-pricing-table.subtitle.primary-bg .featured-table-text,
	.ivan-pricing-table.small-desc.primary-bg .featured-table-text {
		color: #24bd82;
	}

	.ivan-button.primary-bg:hover,
	.iv-layout.header input[type=email],.iv-layout.header input[type=password],.iv-layout.header input[type=search],.iv-layout.header input[type=text],.iv-layout.header textarea,
	.iv-layout.header input[type=submit],
	.iv-layout.header .live-search input[type=search]:focus,
	.iv-layout.header .woo-cart .buttons a,
	.iv-layout.header .login-ajax .lwa input:focus,
	.iv-layout.header .login-ajax .lwa input[type=submit],
	.iv-layout.header .login-ajax .lwa input[type=submit]:hover,
	.dynamic-footer .wpb_widgetised_column .widget input[type=submit],.iv-layout.footer .widget input[type=submit],
	.iv-layout.header .live-search .submit-form,
	.iv-layout.header .woo-cart .cart_list img,
	.iv-layout.header .woo-cart .total,
	.iv-layout.header .login-ajax .lwa .lwa-field .fa {
		border-color: #24bd82;
	}

	/* 2% */

	.ivan-service.primary-bg .content-section-holder li,
	.ivan-service.primary-bg .content-section-holder p {
	  border-color: #2ac388;
	}

	/* **** */
	/* WooCommerce Default */
	/* **** */

	::selection {
	  color: #fff;
	  background-color: #31ca8f;
	}

	::-moz-selection {
	  color: #fff;
	  background-color: #31ca8f;
	}

	p.demo_store,
	.woocommerce a.button.alt,
	.woocommerce-page a.button.alt,
	.woocommerce button.button.alt,
	.woocommerce-page button.button.alt,
	.woocommerce input.button.alt,
	.woocommerce-page input.button.alt,
	.woocommerce #respond input#submit.alt,
	.woocommerce-page #respond input#submit.alt,
	.woocommerce a.button.alt:hover,
	.woocommerce-page a.button.alt:hover,
	.woocommerce button.button.alt:hover,
	.woocommerce-page button.button.alt:hover,
	.woocommerce input.button.alt:hover,
	.woocommerce-page input.button.alt:hover,
	.woocommerce #respond input#submit.alt:hover,
	.woocommerce-page #respond input#submit.alt:hover,
	.single-post .entry-tags a:hover {
	  background-color: #31ca8f;
	  border-color: #31ca8f;
	  color: #fff;
	}

	.woocommerce span.onsale,
	.woocommerce-page span.onsale,
	.woocommerce .widget_layered_nav_filters ul li a,
	.woocommerce-page .widget_layered_nav_filters ul li a,
	.sticky-post-holder {
		background-color: #31ca8f;
		color: #fff;
	}

	.woocommerce div.product div.summary .share-icons a:hover,.woocommerce-page div.product div.summary .share-icons a:hover,
	.woocommerce div.product .woocommerce-tabs ul.tabs li.active a,.woocommerce-page div.product .woocommerce-tabs ul.tabs li.active a,
	.woocommerce div.product .woocommerce-tabs ul.tabs.tabs-vertical li a:hover,.woocommerce-page div.product .woocommerce-tabs ul.tabs.tabs-vertical li a:hover,
	.woocommerce table.cart a.remove:hover,.woocommerce-page table.cart a.remove:hover,
	.woocommerce-wishlist .share-icons a:hover {
		color: #31ca8f;
	}

	.woocommerce div.product div.summary .share-icons a:hover,.woocommerce-page div.product div.summary .share-icons a:hover,
	.woocommerce #respond input#submit.alt,.woocommerce a.button.alt,.woocommerce button.button.alt,.woocommerce input.button.alt,.woocommerce-page #respond input#submit.alt,.woocommerce-page a.button.alt,.woocommerce-page button.button.alt,.woocommerce-page input.button.alt,
	.woocommerce table.cart a.remove:hover,.woocommerce-page table.cart a.remove:hover,
	.woocommerce-wishlist .share-icons a:hover,
	.woocommerce div.product .woocommerce-tabs ul.tabs li.active a, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active a {
		border-color: #31ca8f;
	}

			
	.iv-layout.header a {
		color: #ffffff;
	}
	.iv-layout.header .woo-cart .basket-wrapper .top,
	.iv-layout.header .woo-cart .basket-wrapper .basket {
		border-color: #ffffff;
	}
			
	.iv-layout.header a:hover,
	.iv-layout.header .woo-cart:hover .basket {
		color: #bcbcbc;
	}
	.iv-layout.header .woo-cart:hover .basket-wrapper .top,
	.iv-layout.header .woo-cart:hover .basket-wrapper .basket {
		border-color: #bcbcbc;
	}
	</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

<body class="error404 wide ivan-vc-enabled wpb-js-composer js-comp-ver-4.5.2 vc_responsive ivan-m-l-aside ivan-m-l-aside-left">

		<div id="page-loader">
			<!--<i class="fa fa-spinner fa-spin"></i>-->
			<span class="spinner"></span>
			<!--
			<div id="loader-wrapper">
				<div class="loader">Loading...</div>
			</div>
			-->
		</div>


<div id="all-site-wrapper" class="hfeed site">

	<a href="#" id="back-top">
		<i class="fa fa-angle-up " style=""></i>
	</a>

	
		<div class="ivan-ml-aside-container"><div class="ivan-main-layout-aside aside-header-wrapper ivan-main-layout-aside-left">

<div class="iv-layout header simple-left-right fixed-height centered-menu-items standard">
	<div class="container-fit">
		<div class="row-fit">

			<div class="header-top-area">
				<a href="http://october02.themes.tvda.eu/demo02/" class="logo" style=""><img class="sd-res logo-normal" src="http://october02.themes.tvda.eu/demo02/wp-content/uploads/2015/06/demo02-logo-1.png" width="187" height="60" alt="James October" /><img class="hd-res logo-normal" src="http://october02.themes.tvda.eu/demo02/wp-content/uploads/2015/06/demo02-logo-2.png" width="187" height="60" alt="James October" /></a>			</div>

			<div class="header-bottom-area">

				<div class="modules-row">

					
		<div class="iv-module responsive-menu hidden-lg hidden-md">
			<div class="centered">
				<a class="mobile-menu-trigger" href="#" data-selector=".header" data-id="header-menu-wrap"><i class="fa fa-bars"></i></a>
			</div>
		</div>

			

					
					
					
				</div>

				<div class="mega_main_menu nav_menu primary icons-left first-lvl-align-left first-lvl-separator-none direction-vertical responsive-disable mobile_minimized-disable dropdowns_animation-none version-1-1-0 hidden-xs hidden-sm iv-module menu-wrapper no-search">
				<ul id="menu-main-menu" class="mega_main_menu_ul  menu"><li id="menu-item-157" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-157 default_dropdown default_style drop_to_right  submenu_default_width columns1"><a href="http://october02.themes.tvda.eu/demo02/" class="item_link  disable_icon"><span class="item_link_content"><span class="link_text">Home</span></span></a></li>
<li id="menu-item-160" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-160 default_dropdown default_style drop_to_right  submenu_default_width columns1"><a href="http://october02.themes.tvda.eu/demo02/about-me/" class="item_link  disable_icon"><span class="item_link_content"><span class="link_text">About Me</span></span></a></li>
<li id="menu-item-158" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-158 default_dropdown default_style drop_to_right  submenu_default_width columns1"><a href="http://october02.themes.tvda.eu/demo02/portfolio/" class="item_link  disable_icon"><span class="item_link_content"><span class="link_text">Portfolio</span></span></a></li>
<li id="menu-item-159" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-159 default_dropdown default_style drop_to_right  submenu_default_width columns1"><a href="http://october02.themes.tvda.eu/demo02/instagram-feed/" class="item_link  disable_icon"><span class="item_link_content"><span class="link_text">Instagram Feed</span></span></a></li>
<li id="menu-item-156" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-156 default_dropdown default_style drop_to_right  submenu_default_width columns1"><a href="http://october02.themes.tvda.eu/demo02/blog/" class="item_link  disable_icon"><span class="item_link_content"><span class="link_text">Blog</span></span></a></li>
<li id="menu-item-155" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-155 default_dropdown default_style drop_to_right  submenu_default_width columns1"><a href="http://october02.themes.tvda.eu/demo02/contact-me/" class="item_link  disable_icon"><span class="item_link_content"><span class="link_text">Contact Me</span></span></a></li>
</ul><!-- /class="mega_main_menu_ul  menu" --></div>
				<div class="hidden-xs hidden-sm single-module-row">
					
		<div class="iv-module social-icons hidden-xs hidden-sm">
			<div class="centered">
			
									<a href="#" target="_blank"><i class="fa fw fa-facebook"></i></a>
									<a href="#" target="_blank"><i class="fa fw fa-pinterest"></i></a>
									<a href="#" target="_blank"><i class="fa fw fa-instagram"></i></a>
				
						</div>
		</div>

		
									</div>

				<div class="hidden-xs hidden-sm portfolio-filter-receiver">

				</div>

				
					<div class="hidden-xs hidden-sm widget-area">
											</div>

				
			</div>

		</div>					
	</div>
</div></div><div class="ivan-main-layout-aside-right">
		
	<div class="title-wrapper-divider"></div>		
		
	<div class="iv-layout content-wrapper not-found ">
		<div class="container">
			<div class="row">

				<div class="col-md-12">

					<h2 class="not-found-number">Error 404<span class="error-dot">.</span></h2>
					<h4 class="not-found-text">It looks like nothing was found at this location. Try use the search.</h4>

				</div>

			</div>	
		</div>
	</div>

			
		

		






	<div class="iv-layout bottom-footer two-columns ">
		<div class="container">
			<div class="row">

				
				<div class="col-xs-6 col-sm-6 col-md-6 bottom-footer-left-area">

					
		<div class="iv-module custom-text ">
			<div class="centered">
				<div style="text-align: center;">ALL RIGHT RESERVED.</div>			</div>
		</div>

		
					
								</div>
				
				<div class="col-xs-6 col-sm-6 col-md-6 bottom-footer-right-area">
				
					
					
									</div>

			</div>					
		</div>
	</div>


</div><!-- .ivan-main-layout-aside-right --><div style="clear: both;"></div></div><!-- .ivan-aside-container -->
	
</div><!-- #all-site-wrapper -->

<style type="text/css"></style><script type='text/javascript'>
/* <![CDATA[ */
var sb_instagram_js_options = {"sb_instagram_at":"5983766.97584da.93068c83f99c41fe9f9e60b8406762b2"};
/* ]]> */
</script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-content/plugins/instagram-feed/js/sb-instagram.js?ver=1.3.7'></script>
<script type='text/javascript' src='//october02.themes.tvda.eu/demo02/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.60'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/demo02\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='//october02.themes.tvda.eu/demo02/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=2.3.10'></script>
<script type='text/javascript' src='//october02.themes.tvda.eu/demo02/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/demo02\/wp-admin\/admin-ajax.php","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type='text/javascript' src='//october02.themes.tvda.eu/demo02/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=2.3.10'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var yith_wcwl_l10n = {"ajax_url":"http:\/\/october02.themes.tvda.eu\/demo02\/wp-admin\/admin-ajax.php","redirect_to_cart":"no","multi_wishlist":"","hide_add_button":"1","is_user_logged_in":"","ajax_loader_url":"http:\/\/october02.themes.tvda.eu\/demo02\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader.gif","remove_from_wishlist_after_add_to_cart":"yes","labels":{"cookie_disabled":"We are sorry,but this feature is available only if cookies on your browser are enabled."},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.yith-wcwl.js?ver=2.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ivan_vc = {"isAdmin":"","container":".content-wrapper"};
/* ]]> */
</script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-content/plugins/elite-addons-vc/assets/modules.min.js?ver=1.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ivan_theme_scripts = {"ajaxurl":"http:\/\/october02.themes.tvda.eu\/demo02\/wp-admin\/admin-ajax.php","nonce":"d583f5e6e0","preload":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/js/theme-scripts.min.js?ver=1'></script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/css/libs/owl-carousel/owl.carousel.min.js?ver=1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_variation_params = {"i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};
/* ]]> */
</script>
<script type='text/javascript' src='http://october02.themes.tvda.eu/demo02/wp-content/themes/october/js/woocommerce/woo-scripts.js?ver=1'></script>
<script type="text/javascript">
                                    </script>
	
</body>
</html>